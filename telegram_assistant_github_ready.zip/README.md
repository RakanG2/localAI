# Telegram Assistant AI 🤖

Телеграм-бот с функциями:
- Напоминания /newtask, /today
- Интеграция с ChatGPT (/chat)
- Только для владельца (по Telegram ID)

## Переменные окружения:
- `TELEGRAM_TOKEN`
- `OPENAI_API_KEY`
- `OWNER_ID`
